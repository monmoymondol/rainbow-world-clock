# Live Clock Website - MVP Todo

## Features to Implement:
1. **Real-time Digital Clock** - Display current time in HH:MM:SS format
2. **Real-time Analog Clock** - Traditional clock face with hour, minute, and second hands
3. **Timezone Selection** - Dropdown to choose different timezones/regions
4. **Realistic Design** - Modern, sleek clock interface with proper styling
5. **Live Updates** - Both clocks update every second

## Files to Create/Modify:
1. `src/pages/Index.tsx` - Main clock page with both analog and digital clocks
2. `src/components/DigitalClock.tsx` - Digital clock component
3. `src/components/AnalogClock.tsx` - Analog clock component with SVG
4. `src/components/TimezoneSelector.tsx` - Timezone selection dropdown
5. `src/hooks/useClock.ts` - Custom hook for time management
6. `index.html` - Update title to "Live Clock"

## Implementation Plan:
- Use React hooks (useState, useEffect) for real-time updates
- SVG for analog clock face and hands
- Intl API for timezone handling
- Shadcn-ui components for modern UI
- Tailwind CSS for responsive design and animations
- Dark theme with glassmorphism effects for modern look