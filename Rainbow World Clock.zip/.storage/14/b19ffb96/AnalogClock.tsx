import { useClock } from '@/hooks/useClock';

interface AnalogClockProps {
  timezone: string;
}

export const AnalogClock = ({ timezone }: AnalogClockProps) => {
  const { analogTime } = useClock(timezone);

  const hourAngle = (analogTime.hours * 30) + (analogTime.minutes * 0.5);
  const minuteAngle = analogTime.minutes * 6;
  const secondAngle = analogTime.seconds * 6;

  const hourNumbers = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <div className="flex justify-center">
      <div className="relative">
        <div className="bg-gradient-to-br from-white/20 via-white/10 to-white/5 backdrop-blur-xl rounded-full p-8 border-2 border-white/30 shadow-2xl">
          <svg width="320" height="320" viewBox="0 0 320 320" className="drop-shadow-2xl">
            {/* Outer decorative ring */}
            <circle
              cx="160"
              cy="160"
              r="155"
              fill="none"
              stroke="url(#rainbowGradient)"
              strokeWidth="4"
              strokeDasharray="10,5"
              className="animate-spin-slow"
            />
            
            {/* Main clock face */}
            <circle
              cx="160"
              cy="160"
              r="145"
              fill="rgba(255, 255, 255, 0.15)"
              stroke="rgba(255, 255, 255, 0.4)"
              strokeWidth="3"
            />
            
            {/* Inner decorative circle */}
            <circle
              cx="160"
              cy="160"
              r="130"
              fill="none"
              stroke="url(#innerRainbow)"
              strokeWidth="2"
              opacity="0.6"
            />

            {/* Define gradients */}
            <defs>
              <linearGradient id="rainbowGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#ff0000" />
                <stop offset="16.66%" stopColor="#ff8800" />
                <stop offset="33.33%" stopColor="#ffff00" />
                <stop offset="50%" stopColor="#00ff00" />
                <stop offset="66.66%" stopColor="#0088ff" />
                <stop offset="83.33%" stopColor="#4400ff" />
                <stop offset="100%" stopColor="#ff00ff" />
              </linearGradient>
              
              <linearGradient id="innerRainbow" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ff4444" />
                <stop offset="25%" stopColor="#ffff44" />
                <stop offset="50%" stopColor="#44ff44" />
                <stop offset="75%" stopColor="#4444ff" />
                <stop offset="100%" stopColor="#ff44ff" />
              </linearGradient>

              <linearGradient id="hourHand" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="100%" stopColor="#ffdd00" />
              </linearGradient>

              <linearGradient id="minuteHand" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="100%" stopColor="#00ddff" />
              </linearGradient>
            </defs>
            
            {/* Hour markers with rainbow colors */}
            {hourNumbers.map((hour) => {
              const angle = (hour * 30 - 90) * (Math.PI / 180);
              const x1 = 160 + Math.cos(angle) * 115;
              const y1 = 160 + Math.sin(angle) * 115;
              const x2 = 160 + Math.cos(angle) * 130;
              const y2 = 160 + Math.sin(angle) * 130;
              
              const colors = ['#ff0000', '#ff4400', '#ff8800', '#ffcc00', '#ffff00', '#ccff00', '#88ff00', '#44ff00', '#00ff44', '#00ff88', '#00ffcc', '#00ccff'];
              
              return (
                <g key={hour}>
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke={colors[hour - 1]}
                    strokeWidth="4"
                    strokeLinecap="round"
                  />
                  <text
                    x={160 + Math.cos(angle) * 100}
                    y={160 + Math.sin(angle) * 100 + 7}
                    textAnchor="middle"
                    fill="white"
                    fontSize="20"
                    fontWeight="bold"
                    filter="drop-shadow(2px 2px 4px rgba(0,0,0,0.5))"
                  >
                    {hour}
                  </text>
                </g>
              );
            })}

            {/* Minute markers */}
            {Array.from({ length: 60 }, (_, i) => {
              if (i % 5 !== 0) {
                const angle = (i * 6 - 90) * (Math.PI / 180);
                const x1 = 160 + Math.cos(angle) * 120;
                const y1 = 160 + Math.sin(angle) * 120;
                const x2 = 160 + Math.cos(angle) * 125;
                const y2 = 160 + Math.sin(angle) * 125;
                
                return (
                  <line
                    key={i}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="rgba(255, 255, 255, 0.7)"
                    strokeWidth="1.5"
                  />
                );
              }
              return null;
            })}

            {/* Hour hand with gradient */}
            <line
              x1="160"
              y1="160"
              x2={160 + Math.cos((hourAngle - 90) * (Math.PI / 180)) * 65}
              y2={160 + Math.sin((hourAngle - 90) * (Math.PI / 180)) * 65}
              stroke="url(#hourHand)"
              strokeWidth="8"
              strokeLinecap="round"
              filter="drop-shadow(2px 2px 6px rgba(0,0,0,0.4))"
              style={{ transition: 'all 0.5s ease-in-out' }}
            />

            {/* Minute hand with gradient */}
            <line
              x1="160"
              y1="160"
              x2={160 + Math.cos((minuteAngle - 90) * (Math.PI / 180)) * 90}
              y2={160 + Math.sin((minuteAngle - 90) * (Math.PI / 180)) * 90}
              stroke="url(#minuteHand)"
              strokeWidth="6"
              strokeLinecap="round"
              filter="drop-shadow(2px 2px 6px rgba(0,0,0,0.4))"
              style={{ transition: 'all 0.5s ease-in-out' }}
            />

            {/* Second hand with rainbow effect */}
            <line
              x1="160"
              y1="160"
              x2={160 + Math.cos((secondAngle - 90) * (Math.PI / 180)) * 105}
              y2={160 + Math.sin((secondAngle - 90) * (Math.PI / 180)) * 105}
              stroke="#ff0066"
              strokeWidth="3"
              strokeLinecap="round"
              filter="drop-shadow(0px 0px 8px #ff0066)"
              style={{ transition: 'all 0.1s ease-out' }}
            />

            {/* Center decoration */}
            <circle cx="160" cy="160" r="12" fill="url(#rainbowGradient)" />
            <circle cx="160" cy="160" r="8" fill="white" />
            <circle cx="160" cy="160" r="4" fill="#ff0066" />
          </svg>
        </div>
      </div>
    </div>
  );
};