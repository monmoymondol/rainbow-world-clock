import { useClock } from '@/hooks/useClock';

interface DigitalClockProps {
  timezone: string;
}

export const DigitalClock = ({ timezone }: DigitalClockProps) => {
  const { digitalTime, date } = useClock(timezone);

  return (
    <div className="text-center space-y-4">
      <div className="bg-black/30 backdrop-blur-md rounded-2xl p-8 border border-white/20 shadow-2xl">
        <div className="text-6xl md:text-8xl font-mono font-bold text-white tracking-wider">
          {digitalTime}
        </div>
        <div className="text-lg md:text-xl text-white/80 mt-4 font-medium">
          {date}
        </div>
      </div>
    </div>
  );
};