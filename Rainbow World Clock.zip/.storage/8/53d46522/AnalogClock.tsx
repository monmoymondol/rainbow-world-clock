import { useClock } from '@/hooks/useClock';

interface AnalogClockProps {
  timezone: string;
}

export const AnalogClock = ({ timezone }: AnalogClockProps) => {
  const { analogTime } = useClock(timezone);

  const hourAngle = (analogTime.hours * 30) + (analogTime.minutes * 0.5);
  const minuteAngle = analogTime.minutes * 6;
  const secondAngle = analogTime.seconds * 6;

  const hourNumbers = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <div className="flex justify-center">
      <div className="relative">
        <div className="bg-white/10 backdrop-blur-md rounded-full p-8 border border-white/20 shadow-2xl">
          <svg width="300" height="300" viewBox="0 0 300 300" className="drop-shadow-lg">
            {/* Clock face */}
            <circle
              cx="150"
              cy="150"
              r="140"
              fill="rgba(255, 255, 255, 0.1)"
              stroke="rgba(255, 255, 255, 0.3)"
              strokeWidth="2"
            />
            
            {/* Hour markers */}
            {hourNumbers.map((hour) => {
              const angle = (hour * 30 - 90) * (Math.PI / 180);
              const x1 = 150 + Math.cos(angle) * 120;
              const y1 = 150 + Math.sin(angle) * 120;
              const x2 = 150 + Math.cos(angle) * 130;
              const y2 = 150 + Math.sin(angle) * 130;
              
              return (
                <g key={hour}>
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="white"
                    strokeWidth="3"
                  />
                  <text
                    x={150 + Math.cos(angle) * 105}
                    y={150 + Math.sin(angle) * 105 + 6}
                    textAnchor="middle"
                    fill="white"
                    fontSize="18"
                    fontWeight="bold"
                  >
                    {hour}
                  </text>
                </g>
              );
            })}

            {/* Minute markers */}
            {Array.from({ length: 60 }, (_, i) => {
              if (i % 5 !== 0) {
                const angle = (i * 6 - 90) * (Math.PI / 180);
                const x1 = 150 + Math.cos(angle) * 125;
                const y1 = 150 + Math.sin(angle) * 125;
                const x2 = 150 + Math.cos(angle) * 130;
                const y2 = 150 + Math.sin(angle) * 130;
                
                return (
                  <line
                    key={i}
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="rgba(255, 255, 255, 0.6)"
                    strokeWidth="1"
                  />
                );
              }
              return null;
            })}

            {/* Hour hand */}
            <line
              x1="150"
              y1="150"
              x2={150 + Math.cos((hourAngle - 90) * (Math.PI / 180)) * 60}
              y2={150 + Math.sin((hourAngle - 90) * (Math.PI / 180)) * 60}
              stroke="white"
              strokeWidth="6"
              strokeLinecap="round"
              style={{ transition: 'all 0.5s ease-in-out' }}
            />

            {/* Minute hand */}
            <line
              x1="150"
              y1="150"
              x2={150 + Math.cos((minuteAngle - 90) * (Math.PI / 180)) * 85}
              y2={150 + Math.sin((minuteAngle - 90) * (Math.PI / 180)) * 85}
              stroke="white"
              strokeWidth="4"
              strokeLinecap="round"
              style={{ transition: 'all 0.5s ease-in-out' }}
            />

            {/* Second hand */}
            <line
              x1="150"
              y1="150"
              x2={150 + Math.cos((secondAngle - 90) * (Math.PI / 180)) * 100}
              y2={150 + Math.sin((secondAngle - 90) * (Math.PI / 180)) * 100}
              stroke="#ef4444"
              strokeWidth="2"
              strokeLinecap="round"
              style={{ transition: 'all 0.1s ease-out' }}
            />

            {/* Center dot */}
            <circle cx="150" cy="150" r="8" fill="white" />
            <circle cx="150" cy="150" r="4" fill="#ef4444" />
          </svg>
        </div>
      </div>
    </div>
  );
};