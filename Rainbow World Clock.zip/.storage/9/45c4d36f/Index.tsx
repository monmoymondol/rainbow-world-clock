import { useState } from 'react';
import { DigitalClock } from '@/components/DigitalClock';
import { AnalogClock } from '@/components/AnalogClock';
import { TimezoneSelector } from '@/components/TimezoneSelector';

export default function Index() {
  const [selectedTimezone, setSelectedTimezone] = useState('UTC');

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent mb-4">
            Live World Clock
          </h1>
          <p className="text-xl text-white/70 mb-8">
            Real-time analog and digital clocks with timezone selection
          </p>
          
          {/* Timezone Selector */}
          <div className="flex justify-center">
            <TimezoneSelector
              selectedTimezone={selectedTimezone}
              onTimezoneChange={setSelectedTimezone}
            />
          </div>
        </div>

        {/* Clocks Container */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Analog Clock */}
          <div className="flex flex-col items-center space-y-6">
            <h2 className="text-2xl font-semibold text-white/90">Analog Clock</h2>
            <AnalogClock timezone={selectedTimezone} />
          </div>

          {/* Digital Clock */}
          <div className="flex flex-col items-center space-y-6">
            <h2 className="text-2xl font-semibold text-white/90">Digital Clock</h2>
            <DigitalClock timezone={selectedTimezone} />
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16">
          <div className="bg-white/5 backdrop-blur-md rounded-lg p-6 border border-white/10">
            <p className="text-white/60 text-sm">
              Current timezone: <span className="text-white font-medium">{selectedTimezone}</span>
            </p>
            <p className="text-white/40 text-xs mt-2">
              Updates every second • Built with React & Tailwind CSS
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}