import { useState, useEffect } from 'react';

export const useClock = (timezone: string = 'UTC') => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const getTimeInTimezone = () => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(time);
  };

  const getDateInTimezone = () => {
    return new Intl.DateTimeFormat('en-US', {
      timeZone: timezone,
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    }).format(time);
  };

  const getTimeForAnalog = () => {
    const timeInTimezone = new Date(time.toLocaleString("en-US", { timeZone: timezone }));
    return {
      hours: timeInTimezone.getHours() % 12,
      minutes: timeInTimezone.getMinutes(),
      seconds: timeInTimezone.getSeconds(),
    };
  };

  return {
    time,
    digitalTime: getTimeInTimezone(),
    date: getDateInTimezone(),
    analogTime: getTimeForAnalog(),
  };
};