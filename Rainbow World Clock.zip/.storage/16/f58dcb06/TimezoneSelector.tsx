import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface TimezoneSelectorProps {
  selectedTimezone: string;
  onTimezoneChange: (timezone: string) => void;
}

const timezones = [
  { value: 'UTC', label: '🌍 UTC (Coordinated Universal Time)', emoji: '🌍' },
  { value: 'America/New_York', label: '🗽 New York (EST/EDT)', emoji: '🗽' },
  { value: 'America/Los_Angeles', label: '🌴 Los Angeles (PST/PDT)', emoji: '🌴' },
  { value: 'America/Chicago', label: '🏙️ Chicago (CST/CDT)', emoji: '🏙️' },
  { value: 'Europe/London', label: '🇬🇧 London (GMT/BST)', emoji: '🇬🇧' },
  { value: 'Europe/Paris', label: '🗼 Paris (CET/CEST)', emoji: '🗼' },
  { value: 'Europe/Berlin', label: '🇩🇪 Berlin (CET/CEST)', emoji: '🇩🇪' },
  { value: 'Asia/Tokyo', label: '🗾 Tokyo (JST)', emoji: '🗾' },
  { value: 'Asia/Shanghai', label: '🏮 Shanghai (CST)', emoji: '🏮' },
  { value: 'Asia/Dubai', label: '🏜️ Dubai (GST)', emoji: '🏜️' },
  { value: 'Australia/Sydney', label: '🦘 Sydney (AEST/AEDT)', emoji: '🦘' },
  { value: 'Pacific/Honolulu', label: '🌺 Honolulu (HST)', emoji: '🌺' },
];

export const TimezoneSelector = ({ selectedTimezone, onTimezoneChange }: TimezoneSelectorProps) => {
  const selectedTz = timezones.find(tz => tz.value === selectedTimezone);

  return (
    <div className="w-full max-w-md">
      <Select value={selectedTimezone} onValueChange={onTimezoneChange}>
        <SelectTrigger className="w-full bg-gradient-to-r from-white/20 to-white/10 backdrop-blur-xl border-2 border-white/30 text-white text-lg py-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
          <SelectValue placeholder="🌍 Select timezone">
            <div className="flex items-center space-x-2">
              <span className="text-xl">{selectedTz?.emoji}</span>
              <span className="font-medium">{selectedTz?.label}</span>
            </div>
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="bg-gradient-to-br from-gray-900/95 to-purple-900/95 backdrop-blur-xl border-2 border-white/20 rounded-xl shadow-2xl">
          {timezones.map((tz) => (
            <SelectItem 
              key={tz.value} 
              value={tz.value}
              className="text-white hover:bg-gradient-to-r hover:from-white/20 hover:to-white/10 focus:bg-gradient-to-r focus:from-white/20 focus:to-white/10 py-3 px-4 rounded-lg margin-1 transition-all duration-200"
            >
              <div className="flex items-center space-x-3">
                <span className="text-xl">{tz.emoji}</span>
                <span className="font-medium">{tz.label}</span>
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};