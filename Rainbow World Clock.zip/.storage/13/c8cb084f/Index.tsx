import { useState } from 'react';
import { DigitalClock } from '@/components/DigitalClock';
import { AnalogClock } from '@/components/AnalogClock';
import { TimezoneSelector } from '@/components/TimezoneSelector';

export default function Index() {
  const [selectedTimezone, setSelectedTimezone] = useState('UTC');

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Animated Rainbow Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 via-yellow-500/20 via-green-500/20 via-blue-500/20 via-indigo-500/20 to-purple-500/20 animate-pulse"></div>
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-red-400 via-yellow-400 via-green-400 via-blue-400 via-indigo-400 to-purple-400 animate-gradient-x"></div>
        </div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white/20 rounded-full animate-float"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="relative z-10 p-6">
        <div className="container mx-auto max-w-6xl">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="relative">
              <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-pink-400 via-purple-400 via-blue-400 via-green-400 via-yellow-400 to-red-400 bg-clip-text text-transparent mb-6 animate-gradient-text">
                ✨ Rainbow World Clock ✨
              </h1>
              <div className="absolute -top-2 -left-2 text-6xl md:text-8xl animate-spin-slow">⭐</div>
              <div className="absolute -top-4 -right-4 text-4xl md:text-6xl animate-bounce">🌈</div>
            </div>
            
            <p className="text-xl md:text-2xl text-white/90 mb-8 font-medium">
              🕐 Real-time magical clocks with rainbow themes 🎨
            </p>
            
            {/* Enhanced Timezone Selector */}
            <div className="flex justify-center mb-8">
              <div className="bg-white/10 backdrop-blur-xl rounded-2xl p-6 border border-white/30 shadow-2xl">
                <div className="text-white/80 mb-3 font-medium">🌍 Choose Your Timezone</div>
                <TimezoneSelector
                  selectedTimezone={selectedTimezone}
                  onTimezoneChange={setSelectedTimezone}
                />
              </div>
            </div>
          </div>

          {/* Enhanced Clocks Container */}
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-16 items-center">
            {/* Analog Clock */}
            <div className="flex flex-col items-center space-y-8">
              <div className="flex items-center space-x-3">
                <span className="text-3xl">🕐</span>
                <h2 className="text-3xl font-bold bg-gradient-to-r from-pink-300 to-purple-300 bg-clip-text text-transparent">
                  Analog Clock
                </h2>
                <span className="text-3xl">⚙️</span>
              </div>
              
              <div className="relative">
                {/* Glowing Ring Effect */}
                <div className="absolute -inset-8 bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 rounded-full opacity-20 animate-pulse blur-xl"></div>
                <div className="absolute -inset-4 bg-gradient-to-r from-blue-500 via-green-500 to-yellow-500 rounded-full opacity-30 animate-spin-slow blur-lg"></div>
                
                <AnalogClock timezone={selectedTimezone} />
              </div>
            </div>

            {/* Digital Clock */}
            <div className="flex flex-col items-center space-y-8">
              <div className="flex items-center space-x-3">
                <span className="text-3xl">📱</span>
                <h2 className="text-3xl font-bold bg-gradient-to-r from-green-300 to-blue-300 bg-clip-text text-transparent">
                  Digital Clock
                </h2>
                <span className="text-3xl">💎</span>
              </div>
              
              <div className="relative">
                {/* Digital Clock Glow */}
                <div className="absolute -inset-6 bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 rounded-3xl opacity-20 animate-pulse blur-xl"></div>
                
                <DigitalClock timezone={selectedTimezone} />
              </div>
            </div>
          </div>

          {/* Enhanced Footer */}
          <div className="text-center mt-20">
            <div className="bg-gradient-to-r from-white/5 via-white/10 to-white/5 backdrop-blur-xl rounded-2xl p-8 border border-white/20 shadow-2xl">
              <div className="flex items-center justify-center space-x-2 mb-4">
                <span className="text-2xl">🌐</span>
                <p className="text-white/80 text-lg font-medium">
                  Current timezone: <span className="text-yellow-300 font-bold">{selectedTimezone}</span>
                </p>
                <span className="text-2xl">⏰</span>
              </div>
              
              <div className="flex items-center justify-center space-x-4 text-white/60 text-sm">
                <span>🔄 Updates every second</span>
                <span>•</span>
                <span>🎨 Rainbow theme</span>
                <span>•</span>
                <span>✨ Built with magic</span>
              </div>
              
              <div className="mt-6 flex justify-center space-x-4">
                <span className="text-2xl animate-bounce">🎊</span>
                <span className="text-2xl animate-pulse">🌟</span>
                <span className="text-2xl animate-bounce" style={{ animationDelay: '0.5s' }}>🎉</span>
                <span className="text-2xl animate-pulse" style={{ animationDelay: '1s' }}>💫</span>
                <span className="text-2xl animate-bounce" style={{ animationDelay: '1.5s' }}>🎈</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}