import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface TimezoneSelectorProps {
  selectedTimezone: string;
  onTimezoneChange: (timezone: string) => void;
}

const timezones = [
  { value: 'UTC', label: 'UTC (Coordinated Universal Time)' },
  { value: 'America/New_York', label: 'New York (EST/EDT)' },
  { value: 'America/Los_Angeles', label: 'Los Angeles (PST/PDT)' },
  { value: 'America/Chicago', label: 'Chicago (CST/CDT)' },
  { value: 'Europe/London', label: 'London (GMT/BST)' },
  { value: 'Europe/Paris', label: 'Paris (CET/CEST)' },
  { value: 'Europe/Berlin', label: 'Berlin (CET/CEST)' },
  { value: 'Asia/Tokyo', label: 'Tokyo (JST)' },
  { value: 'Asia/Shanghai', label: 'Shanghai (CST)' },
  { value: 'Asia/Dubai', label: 'Dubai (GST)' },
  { value: 'Australia/Sydney', label: 'Sydney (AEST/AEDT)' },
  { value: 'Pacific/Honolulu', label: 'Honolulu (HST)' },
];

export const TimezoneSelector = ({ selectedTimezone, onTimezoneChange }: TimezoneSelectorProps) => {
  return (
    <div className="w-full max-w-md">
      <Select value={selectedTimezone} onValueChange={onTimezoneChange}>
        <SelectTrigger className="w-full bg-white/10 backdrop-blur-md border-white/20 text-white">
          <SelectValue placeholder="Select timezone" />
        </SelectTrigger>
        <SelectContent className="bg-gray-900/95 backdrop-blur-md border-white/20">
          {timezones.map((tz) => (
            <SelectItem 
              key={tz.value} 
              value={tz.value}
              className="text-white hover:bg-white/10 focus:bg-white/10"
            >
              {tz.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};