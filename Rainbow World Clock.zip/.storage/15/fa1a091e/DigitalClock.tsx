import { useClock } from '@/hooks/useClock';

interface DigitalClockProps {
  timezone: string;
}

export const DigitalClock = ({ timezone }: DigitalClockProps) => {
  const { digitalTime, date } = useClock(timezone);

  return (
    <div className="text-center space-y-6">
      <div className="bg-gradient-to-br from-black/40 via-purple-900/30 to-black/40 backdrop-blur-xl rounded-3xl p-10 border-2 border-white/30 shadow-2xl relative overflow-hidden">
        {/* Animated background pattern */}
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-yellow-500/10 via-green-500/10 via-blue-500/10 via-indigo-500/10 to-purple-500/10 animate-gradient-x"></div>
        
        {/* Digital time display */}
        <div className="relative z-10">
          <div className="text-6xl md:text-9xl font-mono font-bold bg-gradient-to-r from-pink-400 via-purple-400 via-blue-400 via-green-400 via-yellow-400 to-red-400 bg-clip-text text-transparent tracking-wider animate-gradient-text filter drop-shadow-lg">
            {digitalTime}
          </div>
          
          {/* Glowing underline effect */}
          <div className="h-1 bg-gradient-to-r from-pink-500 via-purple-500 via-blue-500 via-green-500 via-yellow-500 to-red-500 rounded-full mt-4 animate-gradient-x shadow-lg"></div>
        </div>
        
        {/* Date display */}
        <div className="relative z-10 mt-8">
          <div className="text-lg md:text-2xl text-white/90 font-semibold bg-gradient-to-r from-blue-200 to-purple-200 bg-clip-text text-transparent">
            📅 {date}
          </div>
        </div>

        {/* Decorative elements */}
        <div className="absolute top-4 left-4 text-2xl animate-pulse">✨</div>
        <div className="absolute top-4 right-4 text-2xl animate-bounce">💎</div>
        <div className="absolute bottom-4 left-4 text-2xl animate-spin-slow">⭐</div>
        <div className="absolute bottom-4 right-4 text-2xl animate-pulse" style={{ animationDelay: '1s' }}>🌟</div>
      </div>
    </div>
  );
};